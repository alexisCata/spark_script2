# secret_settings
# USER = "kpiuser"
# PASS = "Kpiuser00"
# USER = "apvmuser"
# PASS = "x619q8S5%xHT"
# USER = "rephuser"
# PASS = "0y9%LK9053c4"
USER = "bpd"
PASS = "89y9SFE_86u1"

DATABASE = "hbgdwc"
PORT = 5439
# HOST = "hbg-dwc.cmyg8lhqvadq.eu-west-1.redshift.amazonaws.com"
HOST = "hbg-bpd.csht5fpjb1v3.eu-west-1.redshift.amazonaws.com"

# URL = "jdbc:redshift://hbg-dwc.cmyg8lhqvadq.eu-west-1.redshift.amazonaws.com:5439/hbgdwc"
URL = "jdbc:redshift://hbg-bpd.csht5fpjb1v3.eu-west-1.redshift.amazonaws.com:5439/hbgdwc"
DRIVER = "com.amazon.redshift.jdbc42.Driver"
